require "test_helper"

class ParcelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
